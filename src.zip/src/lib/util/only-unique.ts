export const onlyUnique = (value: unknown, index: number, self: unknown[]) =>
  self.indexOf(value) === index
