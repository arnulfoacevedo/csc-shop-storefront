import { createDirectus, Query, rest } from '@directus/sdk';

const directus = createDirectus(String(process.env.DIRECTUS_SERVER_URL)).with(
  rest({
    onRequest: (options) => ({ ...options, cache: 'no-store' }),
  })
);

export default directus;